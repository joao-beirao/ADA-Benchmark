import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));

        int numLines = Integer.parseInt(bufferReader.readLine());
        DNASolver solver = new DNASolverClass(numLines);

        for (int i = 0; i < numLines; i++) {
            String line = bufferReader.readLine();
            String[] arr = line.split(" ");
            int start = Integer.parseInt(arr[0]);
            int end = Integer.parseInt(arr[1]);
            solver.addFragment(start, end);
        }

        
        Assemble result = solver.solve();

        System.out.println(result.getFragmentCount() + " " + result.getOverlap());

    }

}

