
public interface Fragment {

    int getStart();

    int getEnd();

}