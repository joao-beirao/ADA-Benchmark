
public interface Assemble {

    int getFragmentCount();

    int getOverlap();

    boolean isBetter(Assemble a);

}