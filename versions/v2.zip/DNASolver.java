
public interface DNASolver {

    public Assemble solve();

    public void addFragment(int start, int end);
}