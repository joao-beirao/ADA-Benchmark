public class FragmentClass implements Fragment {
    
    private int start;
    private int end;

    public FragmentClass(int start, int end) {
        this.start = start;
        this.end = end;
    }

    @Override
    public int getStart() {
        return start;
    }

    @Override
    public int getEnd() {
        return end;
    }

}
