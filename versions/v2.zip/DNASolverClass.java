import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * DNASolverClass solves the DNA assembly problem by finding the optimal way to assemble fragments.
 */
public class DNASolverClass implements DNASolver {

    private List<Fragment> fragments;
    // The start and end positions of the final assemble
    private int START;
    private int END;
    

    public DNASolverClass(int numFragments) {
        this.fragments = new ArrayList<>(numFragments);
        this.START = Integer.MAX_VALUE;
        this.END = Integer.MIN_VALUE;
    }

    @Override
    public void addFragment(int start, int end) {
        Fragment fragment = new FragmentClass(start, end);
        this.fragments.add(fragment);   
        if (fragment.getStart() < START ) {
            START  = fragment.getStart();
        }
        if (fragment.getEnd() > END) {
            END = fragment.getEnd();
        }
    }

    

    /**
     * Sorts the fragments based on their start and end positions.
     * The fragments are sorted in ascending order of their start position, and in case of a tie,
     * in descending order of their end position.
     */
    private void sortFragments() {
        Collections.sort(fragments, (frag1, frag2) -> {
            if (frag1.getStart() != frag2.getStart()) {
                return Integer.compare(frag1.getStart(), frag2.getStart());
            } else {
                return Integer.compare(frag2.getEnd(), frag1.getEnd());
            }
        });

    }

    /**
     * Solves the DNA assembly problem by finding the optimal way to assemble fragments.
     * @return The best assembly result.
     */
    @Override
    public Assemble solve() {

        if (fragments.isEmpty()) {
            return new AssembleClass(0, 0);
        }

        this.sortFragments();
        
        int arrayOffset = -(START - 1);

        // Array from [START - 1 (...) END+1]
        Assemble[] bestAssemble = new Assemble[END + 1 + arrayOffset];
        for (int i = 0; i < bestAssemble.length; i++) {
            bestAssemble[i] = new AssembleClass(Integer.MAX_VALUE, Integer.MAX_VALUE);
        }
        
        // Base Case
        // bestAssemble[0] = Assemble(0, 0);
        bestAssemble[START - 1 + arrayOffset] = new AssembleClass(0, 0);

        for (Fragment frag : fragments) {

            int fragStart = frag.getStart();
            int fragEnd = frag.getEnd();
            //  
            for (int i = fragStart - 1; i <= fragEnd; i++) {

                Assemble current = bestAssemble[i+arrayOffset];

                if (current.getFragmentCount() != Integer.MAX_VALUE) {   

                    // Calculate Overlap
                    int newEnd = fragEnd;
                    int start = fragStart;
                    int end = Math.min(i, fragEnd);
                    int overlapInc = 0;

                    if (start <= end) {
                        overlapInc = end - start + 1;
                    }

                    // Update the Fragment Count
                    int newCount = current.getFragmentCount() + 1;
                    // Update the Overlap
                    int newOverlap = current.getOverlap() + overlapInc;

                    // Update the bestAssemble if the new assembly is better
                    Assemble existing = bestAssemble[newEnd+arrayOffset];
                    Assemble newAssemble = new AssembleClass(newCount, newOverlap);
                    if (newAssemble.isBetter(existing)) {
                        bestAssemble[newEnd+arrayOffset] = newAssemble;
                    }
                    
                }
            }
        }

        Assemble result = bestAssemble[END+arrayOffset];
        return result;

    }


    
}
