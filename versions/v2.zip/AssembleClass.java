public class AssembleClass implements Assemble {
    private int count;
    private int overlap;

    public AssembleClass(int count, int overlap) {
        this.count = count;
        this.overlap = overlap;
    }

    @Override
    public int getFragmentCount() {
        return count;
    }

    @Override
    public int getOverlap() {
        return overlap;
    }

    @Override
    public boolean isBetter(Assemble a) {
        return 
        this.getFragmentCount() < a.getFragmentCount() || 
        (this.getFragmentCount() == a.getFragmentCount() && this.getOverlap() < a.getOverlap());
    }
    
}
